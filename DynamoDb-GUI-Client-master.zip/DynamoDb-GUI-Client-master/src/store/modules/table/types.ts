export interface TableModuleState {
  newTableMeta: any;
  tableMeta: any;
  showCreateModal: boolean;
  showDeleteModal: boolean;
}
