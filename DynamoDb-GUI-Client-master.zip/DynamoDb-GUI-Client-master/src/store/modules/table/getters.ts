import { GetterTree } from 'vuex';
import { TableModuleState } from './types';
import { RootState } from '@/store/types';

const getters: GetterTree<TableModuleState, RootState> = {};
export default getters;
