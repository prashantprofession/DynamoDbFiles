declare var defaultMenu: any;
declare module 'electron-default-menu' {
  export default defaultMenu;
}
