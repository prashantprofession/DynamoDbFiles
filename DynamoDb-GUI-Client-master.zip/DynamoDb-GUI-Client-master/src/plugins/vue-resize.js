import Vue from 'vue';
import ResSplitPane from 'vue-resize-split-pane';

Vue.component('rs-panes', ResSplitPane);
