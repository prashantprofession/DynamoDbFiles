import Vue from 'vue';
import vueJsonEditor from 'vue-json-editor';
Vue.component('vueJsonEditor', vueJsonEditor);
